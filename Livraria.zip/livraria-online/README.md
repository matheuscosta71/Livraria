# BookStore - Livraria Online

Um site completo de livraria online desenvolvido em HTML, CSS e JavaScript com design moderno e responsivo.

## 🚀 Funcionalidades

### 1. Página Inicial / Catálogo
- ✅ Barra de busca por título, autor ou categoria
- ✅ Filtros laterais: categoria, preço, avaliação, editora
- ✅ Cards dos livros com capa, título, autor, preço, estoque e avaliação
- ✅ Badges visuais para promoções, lançamentos e produtos esgotados
- ✅ Banner promocional no topo
- ✅ Sistema de ordenação (preço, avaliação, lançamentos)

### 2. Página de Detalhes do Livro
- ✅ Capa em destaque com badge de promoção
- ✅ Informações completas: título, autor, editora, ano, ISBN, páginas
- ✅ Sinopse expandida
- ✅ Sistema de avaliações com estrelas e comentários
- ✅ Informações de estoque
- ✅ Seletor de quantidade
- ✅ Botão de adicionar ao carrinho e favoritos
- ✅ Seção "Quem comprou também comprou"

### 3. Carrinho de Compras
- ✅ Lista de itens com capa, título, preço e quantidade
- ✅ Controles de quantidade (+/-)
- ✅ Cálculo automático de subtotais e total
- ✅ Sistema de cupons promocionais
- ✅ Calculadora de frete por CEP
- ✅ Resumo completo do pedido
- ✅ Botões de ação (continuar comprando, limpar carrinho)

### 4. Checkout / Finalização
- ✅ Wizard em 3 etapas
- ✅ Seleção de endereço de entrega
- ✅ Formulário para novo endereço
- ✅ Múltiplas formas de pagamento (cartão, boleto, PIX)
- ✅ Formulário de dados do cartão
- ✅ Revisão final do pedido
- ✅ Modal de confirmação com número do pedido

### 5. Área do Cliente
- ✅ Dashboard com estatísticas pessoais
- ✅ Histórico de pedidos com status
- ✅ Gerenciamento de endereços
- ✅ Gerenciamento de cartões
- ✅ Recomendações personalizadas com IA
- ✅ Insights baseados no histórico
- ✅ Configurações de dados pessoais
- ✅ Configurações de segurança

## 🎨 Design

### Paleta de Cores
- **Azul Principal**: #3498db (confiança e tecnologia)
- **Azul Escuro**: #2980b9 (botões e destaques)
- **Verde**: #27ae60 (sucesso e disponibilidade)
- **Laranja**: #f39c12 (promoções e alertas)
- **Vermelho**: #e74c3c (esgotado e remoções)
- **Cinza**: #ecf0f1 (backgrounds e bordas)

### Características Visuais
- Layout moderno e responsivo
- Cards grandes com imagens chamativas
- Botões coloridos com efeitos hover
- Ícones intuitivos (Font Awesome)
- Gradientes suaves
- Animações de entrada e transições
- Badges e status visuais

## 📱 Responsividade

O site é totalmente responsivo e se adapta a:
- **Desktop**: Layout completo com sidebar
- **Tablet**: Layout adaptado com menu horizontal
- **Mobile**: Layout em coluna única com navegação otimizada

## 🛠️ Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Estilos modernos com Flexbox e Grid
- **JavaScript**: Interatividade e funcionalidades
- **Font Awesome**: Ícones
- **Google Fonts**: Tipografia

## 📁 Estrutura do Projeto

```
livraria-online/
├── index.html              # Página principal
├── css/
│   ├── style.css           # Estilos principais
│   ├── detalhes.css        # Estilos da página de detalhes
│   ├── carrinho.css        # Estilos do carrinho
│   ├── checkout.css        # Estilos do checkout
│   └── cliente.css         # Estilos da área do cliente
├── js/
│   ├── script.js           # JavaScript principal
│   ├── detalhes.js         # Funcionalidades dos detalhes
│   ├── carrinho.js         # Funcionalidades do carrinho
│   ├── checkout.js         # Funcionalidades do checkout
│   └── cliente.js          # Funcionalidades da área do cliente
├── pages/
│   ├── detalhes.html       # Página de detalhes do livro
│   ├── carrinho.html       # Página do carrinho
│   ├── checkout.html       # Página de checkout
│   └── cliente.html        # Área do cliente
├── images/                 # Pasta para imagens
└── README.md              # Documentação
```

## 🚀 Como Usar

1. Abra o arquivo `index.html` em um navegador web
2. Navegue pelas diferentes seções do site
3. Teste as funcionalidades de busca e filtros
4. Adicione itens ao carrinho
5. Explore a área do cliente

## ✨ Funcionalidades JavaScript

### Página Principal
- Busca em tempo real
- Filtros dinâmicos por categoria, preço e avaliação
- Ordenação de produtos
- Animações de entrada
- Notificações de feedback

### Página de Detalhes
- Controle de quantidade
- Sistema de favoritos
- Carregamento dinâmico de avaliações
- Validações de estoque

### Carrinho
- Atualização automática de totais
- Sistema de cupons
- Calculadora de frete
- Animações de remoção

### Checkout
- Wizard de etapas
- Validações de formulário
- Formatação automática de campos
- Modal de confirmação

### Área do Cliente
- Navegação entre seções
- Filtros de pedidos
- Animações de números
- Gerenciamento de dados

## 🎯 Próximas Melhorias

- Integração com backend real
- Sistema de pagamento real
- Notificações push
- Chat de atendimento
- Sistema de reviews mais avançado
- Integração com redes sociais
- PWA (Progressive Web App)

## 📄 Licença

Este projeto foi desenvolvido para fins educacionais e demonstrativos.

