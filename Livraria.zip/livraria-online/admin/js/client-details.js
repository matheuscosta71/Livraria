// JavaScript para página de detalhes do cliente

// Dados simulados do cliente (normalmente viria de uma API)
const clientData = {
    id: 1,
    name: "Maria Silva Santos",
    email: "maria.silva@email.com",
    phone: "(11) 99999-1234",
    cpf: "123.456.789-01",
    birthDate: "1992-05-15",
    gender: "feminino",
    status: "ativo",
    registrationDate: "2023-03-15",
    lastLogin: "2024-08-14 14:30",
    newsletter: true,
    emailVerified: true,
    totalPurchases: 1234.50,
    purchaseCount: 15,
    averageTicket: 82.30,
    lastPurchaseDate: "2024-08-15",
    frequency: 1.2,
    ranking: {
        score: 85,
        level: "Ouro",
        progress: 85
    },
    favoriteCategories: [
        { name: "Ficção", percentage: 60 },
        { name: "Romance", percentage: 25 },
        { name: "Biografia", percentage: 15 }
    ],
    activities: [
        {
            type: "purchase",
            title: "Compra realizada",
            description: "O Hobbit - R$ 45,50",
            date: "15 de agosto, 2024"
        },
        {
            type: "login",
            title: "Login realizado",
            description: "Acesso à conta",
            date: "14 de agosto, 2024"
        },
        {
            type: "update",
            title: "Dados atualizados",
            description: "Endereço de entrega",
            date: "10 de agosto, 2024"
        }
    ],
    addresses: [
        {
            id: 1,
            name: "Casa",
            type: ["entrega", "principal"],
            recipient: "Maria Silva Santos",
            street: "Rua das Flores, 123 - Apto 45",
            neighborhood: "Vila Madalena",
            city: "São Paulo",
            state: "SP",
            cep: "05435-000"
        },
        {
            id: 2,
            name: "Trabalho",
            type: ["cobranca"],
            recipient: "Maria Silva Santos",
            street: "Av. Paulista, 1000 - Sala 1205",
            neighborhood: "Bela Vista",
            city: "São Paulo",
            state: "SP",
            cep: "01310-100"
        }
    ],
    cards: [
        {
            id: 1,
            number: "**** **** **** 1234",
            name: "MARIA SILVA SANTOS",
            expiry: "12/26",
            brand: "visa",
            preferred: true
        },
        {
            id: 2,
            number: "**** **** **** 5678",
            name: "MARIA SILVA SANTOS",
            expiry: "08/27",
            brand: "mastercard",
            preferred: false
        }
    ],
    orders: [
        {
            id: "BS2024001234",
            date: "15 de agosto, 2024",
            status: "entregue",
            items: [
                {
                    title: "O Hobbit",
                    author: "J.R.R. Tolkien",
                    quantity: 1,
                    price: 45.50,
                    image: "https://via.placeholder.com/60x90/4A90E2/FFFFFF?text=O+Hobbit"
                }
            ],
            total: 45.50
        },
        {
            id: "BS2024001198",
            date: "28 de julho, 2024",
            status: "entregue",
            items: [
                {
                    title: "Orgulho e Preconceito",
                    author: "Jane Austen",
                    quantity: 2,
                    price: 77.80,
                    image: "https://via.placeholder.com/60x90/E74C3C/FFFFFF?text=Orgulho+e+Preconceito"
                }
            ],
            total: 77.80
        }
    ]
};

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    initializeTabs();
    loadClientData();
    initializeEventListeners();
});

// Sistema de abas
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetTab = this.dataset.tab;

            // Remover classe active de todos os botões e conteúdos
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Adicionar classe active ao botão clicado e conteúdo correspondente
            this.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
        });
    });
}

// Carregar dados do cliente
function loadClientData() {
    // Atualizar informações do cabeçalho
    updateClientHeader();
    
    // Atualizar dados nas abas
    updateOverviewTab();
    updatePersonalTab();
    updateAddressesTab();
    updateCardsTab();
    updateOrdersTab();
}

// Atualizar cabeçalho do cliente
function updateClientHeader() {
    const nameElement = document.querySelector('.client-main-info h1');
    const emailElement = document.querySelector('.client-email');
    const avatarElement = document.querySelector('.client-avatar-large img');
    
    if (nameElement) nameElement.textContent = clientData.name;
    if (emailElement) emailElement.textContent = clientData.email;
    if (avatarElement) {
        avatarElement.src = `https://via.placeholder.com/120x120/E74C3C/FFFFFF?text=${getInitials(clientData.name)}`;
        avatarElement.alt = clientData.name;
    }

    // Atualizar estatísticas rápidas
    const quickStats = document.querySelectorAll('.quick-stat span');
    if (quickStats.length >= 3) {
        quickStats[0].textContent = `Cliente desde ${formatDate(clientData.registrationDate)}`;
        quickStats[1].textContent = `${clientData.purchaseCount} compras realizadas`;
        quickStats[2].textContent = `R$ ${clientData.totalPurchases.toFixed(2).replace('.', ',')} em compras`;
    }
}

// Atualizar aba de visão geral
function updateOverviewTab() {
    // Estatísticas de compras
    const statsItems = document.querySelectorAll('#overview .stat-item');
    if (statsItems.length >= 4) {
        statsItems[0].querySelector('.stat-value').textContent = `R$ ${clientData.totalPurchases.toFixed(2).replace('.', ',')}`;
        statsItems[1].querySelector('.stat-value').textContent = `R$ ${clientData.averageTicket.toFixed(2).replace('.', ',')}`;
        statsItems[2].querySelector('.stat-value').textContent = formatDate(clientData.lastPurchaseDate);
        statsItems[3].querySelector('.stat-value').textContent = `${clientData.frequency} compras/mês`;
    }

    // Ranking
    const rankingScore = document.querySelector('.ranking-score');
    const rankingLevel = document.querySelector('.ranking-details strong');
    const progressFill = document.querySelector('.progress-fill');
    
    if (rankingScore) rankingScore.textContent = clientData.ranking.score;
    if (rankingLevel) rankingLevel.textContent = `Cliente ${clientData.ranking.level}`;
    if (progressFill) progressFill.style.width = `${clientData.ranking.progress}%`;

    // Categorias favoritas
    const categoriesList = document.querySelector('.categories-list');
    if (categoriesList) {
        categoriesList.innerHTML = clientData.favoriteCategories.map(category => `
            <div class="category-item">
                <span class="category-name">${category.name}</span>
                <div class="category-bar">
                    <div class="category-fill" style="width: ${category.percentage}%"></div>
                </div>
                <span class="category-percent">${category.percentage}%</span>
            </div>
        `).join('');
    }

    // Últimas atividades
    const activitiesList = document.querySelector('.activities-list');
    if (activitiesList) {
        activitiesList.innerHTML = clientData.activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon ${activity.type}">
                    <i class="fas fa-${getActivityIcon(activity.type)}"></i>
                </div>
                <div class="activity-content">
                    <p><strong>${activity.title}</strong></p>
                    <p>${activity.description}</p>
                    <small>${activity.date}</small>
                </div>
            </div>
        `).join('');
    }
}

// Atualizar aba de dados pessoais
function updatePersonalTab() {
    const personalData = [
        { label: 'Nome Completo:', value: clientData.name },
        { label: 'E-mail:', value: clientData.email },
        { label: 'Telefone:', value: clientData.phone },
        { label: 'CPF:', value: clientData.cpf },
        { label: 'Data de Nascimento:', value: formatDate(clientData.birthDate) },
        { label: 'Gênero:', value: clientData.gender === 'feminino' ? 'Feminino' : 'Masculino' }
    ];

    const accountData = [
        { label: 'Data de Cadastro:', value: formatDate(clientData.registrationDate) },
        { label: 'Status da Conta:', value: `<span class="status-badge ${clientData.status}">${clientData.status === 'ativo' ? 'Ativo' : 'Inativo'}</span>` },
        { label: 'Último Login:', value: clientData.lastLogin },
        { label: 'Newsletter:', value: `<span class="status-badge ${clientData.newsletter ? 'active' : 'inactive'}">${clientData.newsletter ? 'Inscrito' : 'Não inscrito'}</span>` },
        { label: 'Verificação de E-mail:', value: `<span class="status-badge ${clientData.emailVerified ? 'active' : 'inactive'}">${clientData.emailVerified ? 'Verificado' : 'Não verificado'}</span>` }
    ];

    updateDataSection('.data-section:first-child .data-list', personalData);
    updateDataSection('.data-section:last-child .data-list', accountData);
}

// Atualizar aba de endereços
function updateAddressesTab() {
    const addressesGrid = document.querySelector('.addresses-grid');
    if (addressesGrid) {
        addressesGrid.innerHTML = clientData.addresses.map(address => `
            <div class="address-card">
                <div class="address-header">
                    <h4>${address.name}</h4>
                    <div class="address-badges">
                        ${address.type.includes('principal') ? '<span class="address-badge primary">Principal</span>' : ''}
                        ${address.type.includes('entrega') ? '<span class="address-badge delivery">Entrega</span>' : ''}
                        ${address.type.includes('cobranca') ? '<span class="address-badge billing">Cobrança</span>' : ''}
                    </div>
                </div>
                <div class="address-content">
                    <p><strong>${address.recipient}</strong></p>
                    <p>${address.street}</p>
                    <p>${address.neighborhood}</p>
                    <p>${address.city} - ${address.state}</p>
                    <p>CEP: ${address.cep}</p>
                </div>
                <div class="address-actions">
                    <button class="btn-edit-address" onclick="editAddress(${address.id})">
                        <i class="fas fa-edit"></i>
                        Editar
                    </button>
                    <button class="btn-delete-address" onclick="deleteAddress(${address.id})">
                        <i class="fas fa-trash"></i>
                        Excluir
                    </button>
                </div>
            </div>
        `).join('');
    }
}

// Atualizar aba de cartões
function updateCardsTab() {
    const cardsGrid = document.querySelector('.cards-grid');
    if (cardsGrid) {
        cardsGrid.innerHTML = clientData.cards.map(card => `
            <div class="card-item">
                <div class="card-visual ${card.brand === 'mastercard' ? 'mastercard' : ''}">
                    <div class="card-type">
                        <i class="fab fa-cc-${card.brand}"></i>
                    </div>
                    <div class="card-number">${card.number}</div>
                    <div class="card-name">${card.name}</div>
                    <div class="card-expiry">${card.expiry}</div>
                    ${card.preferred ? '<div class="card-badges"><span class="card-badge preferred">Preferencial</span></div>' : ''}
                </div>
                <div class="card-actions">
                    <button class="btn-edit-card" onclick="editCard(${card.id})">
                        <i class="fas fa-edit"></i>
                        Editar
                    </button>
                    <button class="btn-delete-card" onclick="deleteCard(${card.id})">
                        <i class="fas fa-trash"></i>
                        Excluir
                    </button>
                </div>
            </div>
        `).join('');
    }
}

// Atualizar aba de pedidos
function updateOrdersTab() {
    const ordersList = document.querySelector('.orders-list');
    if (ordersList) {
        ordersList.innerHTML = clientData.orders.map(order => `
            <div class="order-card">
                <div class="order-header">
                    <div class="order-info">
                        <h4>Pedido #${order.id}</h4>
                        <p>${order.date}</p>
                    </div>
                    <div class="order-status ${order.status}">
                        <i class="fas fa-${getOrderStatusIcon(order.status)}"></i>
                        <span>${getOrderStatusText(order.status)}</span>
                    </div>
                </div>
                <div class="order-items">
                    ${order.items.map(item => `
                        <div class="order-item">
                            <img src="${item.image}" alt="${item.title}">
                            <div class="item-details">
                                <h5>${item.title}</h5>
                                <p>${item.author}</p>
                                <p>Quantidade: ${item.quantity}</p>
                            </div>
                            <div class="item-price">R$ ${item.price.toFixed(2).replace('.', ',')}</div>
                        </div>
                    `).join('')}
                </div>
                <div class="order-footer">
                    <div class="order-total">
                        <span>Total: <strong>R$ ${order.total.toFixed(2).replace('.', ',')}</strong></span>
                    </div>
                    <div class="order-actions">
                        <button class="btn-view-order" onclick="viewOrder('${order.id}')">Ver Detalhes</button>
                    </div>
                </div>
            </div>
        `).join('');
    }
}

// Event Listeners
function initializeEventListeners() {
    // Filtro de pedidos
    const ordersFilter = document.querySelector('.orders-filters select');
    if (ordersFilter) {
        ordersFilter.addEventListener('change', function() {
            filterOrders(this.value);
        });
    }
}

// Funções auxiliares
function updateDataSection(selector, data) {
    const section = document.querySelector(selector);
    if (section) {
        section.innerHTML = data.map(item => `
            <div class="data-item">
                <span class="data-label">${item.label}</span>
                <span class="data-value">${item.value}</span>
            </div>
        `).join('');
    }
}

function getInitials(name) {
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
}

function getActivityIcon(type) {
    const icons = {
        purchase: 'shopping-cart',
        login: 'sign-in-alt',
        update: 'edit'
    };
    return icons[type] || 'circle';
}

function getOrderStatusIcon(status) {
    const icons = {
        processando: 'clock',
        aprovado: 'check',
        transito: 'truck',
        entregue: 'check-circle'
    };
    return icons[status] || 'circle';
}

function getOrderStatusText(status) {
    const texts = {
        processando: 'Processando',
        aprovado: 'Aprovado',
        transito: 'Em Trânsito',
        entregue: 'Entregue'
    };
    return texts[status] || status;
}

// Ações
function editClient() {
    window.location.href = `client-form.html?id=${clientData.id}`;
}

function toggleClientStatus() {
    const newStatus = clientData.status === 'ativo' ? 'inativo' : 'ativo';
    const action = newStatus === 'ativo' ? 'ativar' : 'inativar';
    
    if (confirm(`Tem certeza que deseja ${action} este cliente?`)) {
        clientData.status = newStatus;
        updateClientHeader();
        updatePersonalTab();
        showNotification(`Cliente ${action === 'ativar' ? 'ativado' : 'inativado'} com sucesso!`);
    }
}

function deleteClient() {
    if (confirm('Tem certeza que deseja excluir este cliente? Esta ação não pode ser desfeita.')) {
        showNotification('Cliente excluído com sucesso!');
        setTimeout(() => {
            window.location.href = '../index.html';
        }, 2000);
    }
}

function addAddress() {
    // Implementar modal ou redirecionamento para adicionar endereço
    showNotification('Funcionalidade de adicionar endereço em desenvolvimento');
}

function editAddress(id) {
    showNotification(`Editando endereço ${id}`);
}

function deleteAddress(id) {
    if (confirm('Tem certeza que deseja excluir este endereço?')) {
        clientData.addresses = clientData.addresses.filter(addr => addr.id !== id);
        updateAddressesTab();
        showNotification('Endereço excluído com sucesso!');
    }
}

function addCard() {
    showNotification('Funcionalidade de adicionar cartão em desenvolvimento');
}

function editCard(id) {
    showNotification(`Editando cartão ${id}`);
}

function deleteCard(id) {
    if (confirm('Tem certeza que deseja excluir este cartão?')) {
        clientData.cards = clientData.cards.filter(card => card.id !== id);
        updateCardsTab();
        showNotification('Cartão excluído com sucesso!');
    }
}

function viewOrder(id) {
    showNotification(`Visualizando pedido ${id}`);
}

function filterOrders(status) {
    // Implementar filtro de pedidos
    showNotification(`Filtrando pedidos por status: ${status || 'todos'}`);
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    // Adicionar estilos se não existirem
    if (!document.querySelector('.notification-styles')) {
        const styles = document.createElement('style');
        styles.className = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                border-radius: 8px;
                padding: 1rem 1.5rem;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                display: flex;
                align-items: center;
                gap: 0.8rem;
                z-index: 10000;
                animation: slideIn 0.3s ease-out;
                border-left: 4px solid #27ae60;
            }
            .notification.error {
                border-left-color: #e74c3c;
            }
            .notification i:first-child {
                color: #27ae60;
            }
            .notification.error i:first-child {
                color: #e74c3c;
            }
            .notification button {
                background: none;
                border: none;
                color: #7f8c8d;
                cursor: pointer;
                padding: 0.2rem;
            }
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }

    document.body.appendChild(notification);

    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Exportar funções para uso global
window.editClient = editClient;
window.toggleClientStatus = toggleClientStatus;
window.deleteClient = deleteClient;
window.addAddress = addAddress;
window.editAddress = editAddress;
window.deleteAddress = deleteAddress;
window.addCard = addCard;
window.editCard = editCard;
window.deleteCard = deleteCard;
window.viewOrder = viewOrder;

