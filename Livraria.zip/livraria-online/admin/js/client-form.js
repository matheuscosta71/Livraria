// JavaScript para formulário de cliente

// Estado do formulário
let formData = {
    personal: {},
    addresses: [],
    cards: [],
    password: {}
};

let addressCounter = 1;
let cardCounter = 1;
let isEditMode = false;
let clientId = null;

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    initializeForm();
    initializeTabs();
    initializeValidation();
    initializeMasks();
    checkEditMode();
});

// Verificar se é modo de edição
function checkEditMode() {
    const urlParams = new URLSearchParams(window.location.search);
    clientId = urlParams.get('id');
    
    if (clientId) {
        isEditMode = true;
        document.querySelector('.form-title h1').textContent = 'Editar Cliente';
        document.querySelector('.form-title p').textContent = 'Atualize os dados do cliente abaixo';
        loadClientData(clientId);
    }
}

// Carregar dados do cliente para edição
function loadClientData(id) {
    // Dados simulados (normalmente viria de uma API)
    const clientData = {
        fullName: "Maria Silva Santos",
        email: "maria.silva@email.com",
        phone: "(11) 99999-1234",
        cpf: "123.456.789-01",
        birthDate: "1992-05-15",
        gender: "feminino",
        status: "ativo",
        newsletter: true,
        promotions: true
    };

    // Preencher formulário
    Object.keys(clientData).forEach(key => {
        const field = document.getElementById(key.replace(/([A-Z])/g, '-$1').toLowerCase());
        if (field) {
            if (field.type === 'checkbox') {
                field.checked = clientData[key];
            } else {
                field.value = clientData[key];
            }
        }
    });
}

// Inicializar formulário
function initializeForm() {
    const form = document.getElementById('client-form');
    if (form) {
        form.addEventListener('submit', handleSubmit);
    }
}

// Sistema de abas
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetTab = this.dataset.tab;

            // Remover classe active
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Adicionar classe active
            this.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
        });
    });
}

// Inicializar validação
function initializeValidation() {
    const inputs = document.querySelectorAll('input, select');
    
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });

        input.addEventListener('input', function() {
            clearFieldError(this);
            
            // Validação especial para senhas
            if (this.id === 'new-password') {
                validatePassword(this.value);
            }
            
            if (this.id === 'confirm-password') {
                validatePasswordConfirmation();
            }
        });
    });
}

// Inicializar máscaras
function initializeMasks() {
    // Máscara para telefone
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function() {
            this.value = formatPhone(this.value);
        });
    });

    // Máscara para CPF
    const cpfInput = document.getElementById('cpf');
    if (cpfInput) {
        cpfInput.addEventListener('input', function() {
            this.value = formatCPF(this.value);
        });
    }

    // Máscara para CEP
    const cepInputs = document.querySelectorAll('input[name*="cep"]');
    cepInputs.forEach(input => {
        input.addEventListener('input', function() {
            this.value = formatCEP(this.value);
        });
    });

    // Máscara para cartão
    const cardInputs = document.querySelectorAll('input[name*="number"]');
    cardInputs.forEach(input => {
        input.addEventListener('input', function() {
            this.value = formatCardNumber(this.value);
            detectCardBrand(this);
        });
    });

    // Máscara para validade do cartão
    const expiryInputs = document.querySelectorAll('input[name*="expiry"]');
    expiryInputs.forEach(input => {
        input.addEventListener('input', function() {
            this.value = formatCardExpiry(this.value);
        });
    });
}

// Validação de campos
function validateField(field) {
    const value = field.value.trim();
    const fieldName = field.name || field.id;
    let isValid = true;
    let errorMessage = '';

    // Campos obrigatórios
    if (field.required && !value) {
        isValid = false;
        errorMessage = 'Este campo é obrigatório';
    }
    // Validação de e-mail
    else if (field.type === 'email' && value && !isValidEmail(value)) {
        isValid = false;
        errorMessage = 'E-mail inválido';
    }
    // Validação de CPF
    else if (fieldName.includes('cpf') && value && !isValidCPF(value)) {
        isValid = false;
        errorMessage = 'CPF inválido';
    }
    // Validação de telefone
    else if (field.type === 'tel' && value && !isValidPhone(value)) {
        isValid = false;
        errorMessage = 'Telefone inválido';
    }
    // Validação de CEP
    else if (fieldName.includes('cep') && value && !isValidCEP(value)) {
        isValid = false;
        errorMessage = 'CEP inválido';
    }

    showFieldValidation(field, isValid, errorMessage);
    return isValid;
}

// Mostrar validação do campo
function showFieldValidation(field, isValid, errorMessage) {
    const formGroup = field.closest('.form-group');
    const errorElement = formGroup.querySelector('.error-message');

    // Remover classes anteriores
    formGroup.classList.remove('valid', 'invalid');
    field.classList.remove('success', 'error');

    if (isValid) {
        formGroup.classList.add('valid');
        field.classList.add('success');
        if (errorElement) {
            errorElement.textContent = '';
            errorElement.classList.remove('show');
        }
    } else {
        formGroup.classList.add('invalid');
        field.classList.add('error');
        if (errorElement) {
            errorElement.textContent = errorMessage;
            errorElement.classList.add('show');
        }
    }
}

// Limpar erro do campo
function clearFieldError(field) {
    const formGroup = field.closest('.form-group');
    const errorElement = formGroup.querySelector('.error-message');

    formGroup.classList.remove('invalid');
    field.classList.remove('error');
    
    if (errorElement) {
        errorElement.classList.remove('show');
    }
}

// Validação de senha
function validatePassword(password) {
    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /\d/.test(password),
        special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
    };

    // Atualizar indicadores visuais
    Object.keys(requirements).forEach(req => {
        const element = document.getElementById(`req-${req}`);
        if (element) {
            const icon = element.querySelector('i');
            if (requirements[req]) {
                element.classList.add('valid');
                icon.className = 'fas fa-check';
            } else {
                element.classList.remove('valid');
                icon.className = 'fas fa-times';
            }
        }
    });

    // Calcular força da senha
    const strength = Object.values(requirements).filter(Boolean).length;
    updatePasswordStrength(strength);

    return Object.values(requirements).every(Boolean);
}

// Atualizar força da senha
function updatePasswordStrength(strength) {
    const strengthFill = document.querySelector('.strength-fill');
    const strengthText = document.querySelector('.strength-text');

    if (!strengthFill || !strengthText) return;

    // Remover classes anteriores
    strengthFill.className = 'strength-fill';
    strengthText.className = 'strength-text';

    let level = '';
    let text = '';

    if (strength === 0) {
        text = 'Digite uma senha';
    } else if (strength <= 2) {
        level = 'weak';
        text = 'Senha fraca';
    } else if (strength <= 3) {
        level = 'fair';
        text = 'Senha razoável';
    } else if (strength <= 4) {
        level = 'good';
        text = 'Senha boa';
    } else {
        level = 'strong';
        text = 'Senha forte';
    }

    if (level) {
        strengthFill.classList.add(level);
        strengthText.classList.add(level);
    }
    
    strengthText.textContent = text;
}

// Validar confirmação de senha
function validatePasswordConfirmation() {
    const password = document.getElementById('new-password');
    const confirmPassword = document.getElementById('confirm-password');

    if (!password || !confirmPassword) return;

    const isValid = password.value === confirmPassword.value;
    const errorMessage = isValid ? '' : 'As senhas não coincidem';

    showFieldValidation(confirmPassword, isValid, errorMessage);
    return isValid;
}

// Alternar visibilidade da senha
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const button = input.nextElementSibling;
    const icon = button.querySelector('i');

    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

// Adicionar formulário de endereço
function addAddressForm() {
    addressCounter++;
    const container = document.getElementById('addresses-container');
    
    const addressForm = document.createElement('div');
    addressForm.className = 'address-form';
    addressForm.dataset.addressId = addressCounter;
    
    addressForm.innerHTML = `
        <div class="address-header">
            <h4>Endereço ${addressCounter}</h4>
            <button type="button" class="btn-remove" onclick="removeAddressForm(${addressCounter})">
                <i class="fas fa-trash"></i>
            </button>
        </div>
        
        <div class="form-grid">
            <div class="form-group">
                <label for="address-${addressCounter}-type">Tipo de Endereço *</label>
                <select id="address-${addressCounter}-type" name="addresses[${addressCounter-1}][type]" required>
                    <option value="">Selecione...</option>
                    <option value="entrega">Entrega</option>
                    <option value="cobranca">Cobrança</option>
                    <option value="ambos">Entrega e Cobrança</option>
                </select>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="address-${addressCounter}-name">Nome do Endereço</label>
                <input type="text" id="address-${addressCounter}-name" name="addresses[${addressCounter-1}][name]" placeholder="Ex: Casa, Trabalho">
            </div>
            
            <div class="form-group">
                <label for="address-${addressCounter}-recipient">Nome do Destinatário *</label>
                <input type="text" id="address-${addressCounter}-recipient" name="addresses[${addressCounter-1}][recipient]" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="address-${addressCounter}-cep">CEP *</label>
                <input type="text" id="address-${addressCounter}-cep" name="addresses[${addressCounter-1}][cep]" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="address-${addressCounter}-street">Logradouro *</label>
                <input type="text" id="address-${addressCounter}-street" name="addresses[${addressCounter-1}][street]" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="address-${addressCounter}-number">Número *</label>
                <input type="text" id="address-${addressCounter}-number" name="addresses[${addressCounter-1}][number]" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="address-${addressCounter}-complement">Complemento</label>
                <input type="text" id="address-${addressCounter}-complement" name="addresses[${addressCounter-1}][complement]">
            </div>
            
            <div class="form-group">
                <label for="address-${addressCounter}-neighborhood">Bairro *</label>
                <input type="text" id="address-${addressCounter}-neighborhood" name="addresses[${addressCounter-1}][neighborhood]" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="address-${addressCounter}-city">Cidade *</label>
                <input type="text" id="address-${addressCounter}-city" name="addresses[${addressCounter-1}][city]" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="address-${addressCounter}-state">Estado *</label>
                <select id="address-${addressCounter}-state" name="addresses[${addressCounter-1}][state]" required>
                    <option value="">Selecione...</option>
                    <option value="SP">São Paulo</option>
                    <option value="RJ">Rio de Janeiro</option>
                    <option value="MG">Minas Gerais</option>
                    <!-- Outros estados... -->
                </select>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group checkbox-group">
                <label class="checkbox-label">
                    <input type="checkbox" id="address-${addressCounter}-primary" name="addresses[${addressCounter-1}][primary]">
                    <span class="checkmark"></span>
                    Endereço principal
                </label>
            </div>
        </div>
    `;
    
    container.appendChild(addressForm);
    
    // Adicionar event listeners para os novos campos
    const newInputs = addressForm.querySelectorAll('input, select');
    newInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        if (input.name && input.name.includes('cep')) {
            input.addEventListener('input', function() {
                this.value = formatCEP(this.value);
            });
        }
    });
}

// Remover formulário de endereço
function removeAddressForm(id) {
    const addressForm = document.querySelector(`[data-address-id="${id}"]`);
    if (addressForm) {
        addressForm.remove();
    }
}

// Adicionar formulário de cartão
function addCardForm() {
    cardCounter++;
    const container = document.getElementById('cards-container');
    
    const cardForm = document.createElement('div');
    cardForm.className = 'card-form';
    cardForm.dataset.cardId = cardCounter;
    
    cardForm.innerHTML = `
        <div class="card-header">
            <h4>Cartão ${cardCounter}</h4>
            <button type="button" class="btn-remove" onclick="removeCardForm(${cardCounter})">
                <i class="fas fa-trash"></i>
            </button>
        </div>
        
        <div class="form-grid">
            <div class="form-group">
                <label for="card-${cardCounter}-number">Número do Cartão *</label>
                <input type="text" id="card-${cardCounter}-number" name="cards[${cardCounter-1}][number]" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="card-${cardCounter}-name">Nome no Cartão *</label>
                <input type="text" id="card-${cardCounter}-name" name="cards[${cardCounter-1}][name]" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="card-${cardCounter}-expiry">Data de Validade *</label>
                <input type="text" id="card-${cardCounter}-expiry" name="cards[${cardCounter-1}][expiry]" placeholder="MM/AA" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="card-${cardCounter}-cvv">CVV *</label>
                <input type="text" id="card-${cardCounter}-cvv" name="cards[${cardCounter-1}][cvv]" required>
                <span class="error-message"></span>
            </div>
            
            <div class="form-group">
                <label for="card-${cardCounter}-brand">Bandeira</label>
                <select id="card-${cardCounter}-brand" name="cards[${cardCounter-1}][brand]">
                    <option value="">Detectar automaticamente</option>
                    <option value="visa">Visa</option>
                    <option value="mastercard">Mastercard</option>
                    <option value="amex">American Express</option>
                    <option value="elo">Elo</option>
                    <option value="hipercard">Hipercard</option>
                </select>
            </div>
            
            <div class="form-group checkbox-group">
                <label class="checkbox-label">
                    <input type="checkbox" id="card-${cardCounter}-preferred" name="cards[${cardCounter-1}][preferred]">
                    <span class="checkmark"></span>
                    Cartão preferencial
                </label>
            </div>
        </div>
    `;
    
    container.appendChild(cardForm);
    
    // Adicionar event listeners para os novos campos
    const newInputs = cardForm.querySelectorAll('input, select');
    newInputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        if (input.name && input.name.includes('number')) {
            input.addEventListener('input', function() {
                this.value = formatCardNumber(this.value);
                detectCardBrand(this);
            });
        }
        
        if (input.name && input.name.includes('expiry')) {
            input.addEventListener('input', function() {
                this.value = formatCardExpiry(this.value);
            });
        }
    });
}

// Remover formulário de cartão
function removeCardForm(id) {
    const cardForm = document.querySelector(`[data-card-id="${id}"]`);
    if (cardForm) {
        cardForm.remove();
    }
}

// Detectar bandeira do cartão
function detectCardBrand(input) {
    const number = input.value.replace(/\s/g, '');
    const brandSelect = input.closest('.form-grid').querySelector('select[name*="brand"]');
    
    if (!brandSelect) return;
    
    let brand = '';
    
    if (/^4/.test(number)) {
        brand = 'visa';
    } else if (/^5[1-5]/.test(number) || /^2[2-7]/.test(number)) {
        brand = 'mastercard';
    } else if (/^3[47]/.test(number)) {
        brand = 'amex';
    } else if (/^6[05]/.test(number)) {
        brand = 'hipercard';
    } else if (/^4[0-9]{12}(?:[0-9]{3})?$/.test(number)) {
        brand = 'elo';
    }
    
    if (brand) {
        brandSelect.value = brand;
    }
}

// Funções de formatação
function formatPhone(value) {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 10) {
        return numbers.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
    } else {
        return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
}

function formatCPF(value) {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

function formatCEP(value) {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{5})(\d{3})/, '$1-$2');
}

function formatCardNumber(value) {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{4})(?=\d)/g, '$1 ');
}

function formatCardExpiry(value) {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{2})(\d{2})/, '$1/$2');
}

// Funções de validação
function isValidEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

function isValidCPF(cpf) {
    const numbers = cpf.replace(/\D/g, '');
    return numbers.length === 11;
}

function isValidPhone(phone) {
    const numbers = phone.replace(/\D/g, '');
    return numbers.length >= 10 && numbers.length <= 11;
}

function isValidCEP(cep) {
    const numbers = cep.replace(/\D/g, '');
    return numbers.length === 8;
}

// Submissão do formulário
function handleSubmit(e) {
    e.preventDefault();
    
    if (validateForm()) {
        saveClient();
    }
}

// Validar formulário completo
function validateForm() {
    const inputs = document.querySelectorAll('input[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!validateField(input)) {
            isValid = false;
        }
    });
    
    // Validações específicas
    if (document.getElementById('new-password').value) {
        if (!validatePassword(document.getElementById('new-password').value)) {
            isValid = false;
        }
        
        if (!validatePasswordConfirmation()) {
            isValid = false;
        }
    }
    
    return isValid;
}

// Salvar cliente
function saveClient() {
    const form = document.getElementById('client-form');
    const formData = new FormData(form);
    
    // Mostrar loading
    form.classList.add('form-loading');
    
    // Simular salvamento (normalmente seria uma requisição para API)
    setTimeout(() => {
        form.classList.remove('form-loading');
        
        const message = isEditMode ? 'Cliente atualizado com sucesso!' : 'Cliente cadastrado com sucesso!';
        showSuccessMessage(message);
        
        // Redirecionar após sucesso
        setTimeout(() => {
            window.location.href = '../index.html';
        }, 2000);
    }, 2000);
}

// Cancelar formulário
function cancelForm() {
    if (confirm('Tem certeza que deseja cancelar? Todas as alterações serão perdidas.')) {
        window.location.href = '../index.html';
    }
}

// Mostrar mensagem de sucesso
function showSuccessMessage(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'save-success';
    successDiv.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    
    const formContainer = document.querySelector('.form-container');
    formContainer.insertBefore(successDiv, formContainer.firstChild);
    
    setTimeout(() => {
        successDiv.remove();
    }, 5000);
}

// Exportar funções para uso global
window.togglePassword = togglePassword;
window.addAddressForm = addAddressForm;
window.removeAddressForm = removeAddressForm;
window.addCardForm = addCardForm;
window.removeCardForm = removeCardForm;
window.saveClient = saveClient;
window.cancelForm = cancelForm;

