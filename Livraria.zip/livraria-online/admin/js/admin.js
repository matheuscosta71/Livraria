// JavaScript principal para área administrativa

// Dados simulados dos clientes
const clientsData = [
    {
        id: 1,
        name: "Maria Silva",
        email: "maria.silva@email.com",
        phone: "(11) 99999-1234",
        cpf: "123.456.789-01",
        age: 32,
        gender: "feminino",
        status: "ativo",
        totalPurchases: 1234.50,
        purchaseCount: 15,
        lastPurchase: "O Hobbit - R$ 45,50",
        lastPurchaseDate: "15 de agosto, 2024",
        addresses: 2,
        cards: 1
    },
    {
        id: 2,
        name: "João Santos",
        email: "joao.santos@email.com",
        phone: "(11) 98888-5678",
        cpf: "987.654.321-09",
        age: 28,
        gender: "masculino",
        status: "ativo",
        totalPurchases: 567.80,
        purchaseCount: 8,
        lastPurchase: "Clean Code - R$ 89,90",
        lastPurchaseDate: "20 de agosto, 2024",
        addresses: 1,
        cards: 2
    },
    {
        id: 3,
        name: "Ana Costa",
        email: "ana.costa@email.com",
        phone: "(11) 97777-9012",
        cpf: "456.789.123-45",
        age: 45,
        gender: "feminino",
        status: "inativo",
        totalPurchases: 156.70,
        purchaseCount: 3,
        lastPurchase: "Orgulho e Preconceito - R$ 38,90",
        lastPurchaseDate: "10 de julho, 2024",
        addresses: 1,
        cards: 1
    },
    {
        id: 4,
        name: "Carlos Oliveira",
        email: "carlos.oliveira@email.com",
        phone: "(11) 96666-3456",
        cpf: "789.123.456-78",
        age: 35,
        gender: "masculino",
        status: "ativo",
        totalPurchases: 2156.90,
        purchaseCount: 22,
        lastPurchase: "Steve Jobs - R$ 67,50",
        lastPurchaseDate: "22 de agosto, 2024",
        addresses: 3,
        cards: 2
    }
];

// Estado da aplicação
let currentView = 'cards';
let filteredClients = [...clientsData];
let currentFilters = {
    search: '',
    status: '',
    gender: '',
    sort: 'nome'
};

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    renderClients();
    updateStats();
});

// Event Listeners
function initializeEventListeners() {
    // Busca
    const searchInput = document.getElementById('client-search');
    if (searchInput) {
        searchInput.addEventListener('input', handleSearch);
    }

    // Filtros
    const statusFilter = document.getElementById('status-filter');
    const genderFilter = document.getElementById('gender-filter');
    const sortFilter = document.getElementById('sort-filter');

    if (statusFilter) statusFilter.addEventListener('change', handleFilters);
    if (genderFilter) genderFilter.addEventListener('change', handleFilters);
    if (sortFilter) sortFilter.addEventListener('change', handleFilters);

    // Alternância de visualização
    const viewButtons = document.querySelectorAll('.view-btn');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const view = this.dataset.view;
            switchView(view);
        });
    });

    // Menu do usuário
    const userInfo = document.querySelector('.user-info');
    if (userInfo) {
        userInfo.addEventListener('click', function() {
            const userMenu = document.querySelector('.user-menu');
            if (userMenu) {
                userMenu.style.display = userMenu.style.display === 'block' ? 'none' : 'block';
            }
        });
    }

    // Fechar menu ao clicar fora
    document.addEventListener('click', function(e) {
        const userInfo = document.querySelector('.user-info');
        const userMenu = document.querySelector('.user-menu');
        if (userInfo && userMenu && !userInfo.contains(e.target) && !userMenu.contains(e.target)) {
            userMenu.style.display = 'none';
        }
    });
}

// Busca
function handleSearch(e) {
    currentFilters.search = e.target.value.toLowerCase();
    applyFilters();
}

// Filtros
function handleFilters() {
    const statusFilter = document.getElementById('status-filter');
    const genderFilter = document.getElementById('gender-filter');
    const sortFilter = document.getElementById('sort-filter');

    currentFilters.status = statusFilter ? statusFilter.value : '';
    currentFilters.gender = genderFilter ? genderFilter.value : '';
    currentFilters.sort = sortFilter ? sortFilter.value : 'nome';

    applyFilters();
}

// Aplicar filtros
function applyFilters() {
    filteredClients = clientsData.filter(client => {
        const matchesSearch = !currentFilters.search || 
            client.name.toLowerCase().includes(currentFilters.search) ||
            client.email.toLowerCase().includes(currentFilters.search) ||
            client.cpf.includes(currentFilters.search);

        const matchesStatus = !currentFilters.status || client.status === currentFilters.status;
        const matchesGender = !currentFilters.gender || client.gender === currentFilters.gender;

        return matchesSearch && matchesStatus && matchesGender;
    });

    // Ordenação
    sortClients();
    renderClients();
}

// Ordenação
function sortClients() {
    filteredClients.sort((a, b) => {
        switch (currentFilters.sort) {
            case 'nome':
                return a.name.localeCompare(b.name);
            case 'email':
                return a.email.localeCompare(b.email);
            case 'compras':
                return b.totalPurchases - a.totalPurchases;
            case 'cadastro':
                return new Date(b.id) - new Date(a.id); // Simulando data de cadastro pelo ID
            default:
                return 0;
        }
    });
}

// Alternar visualização
function switchView(view) {
    currentView = view;
    
    // Atualizar botões
    document.querySelectorAll('.view-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-view="${view}"]`).classList.add('active');

    // Mostrar/ocultar visualizações
    document.getElementById('cards-view').classList.toggle('hidden', view !== 'cards');
    document.getElementById('table-view').classList.toggle('hidden', view !== 'table');
}

// Renderizar clientes
function renderClients() {
    if (currentView === 'cards') {
        renderCardsView();
    } else {
        renderTableView();
    }
}

// Renderizar visualização em cards
function renderCardsView() {
    const container = document.querySelector('.clients-grid');
    if (!container) return;

    container.innerHTML = filteredClients.map(client => `
        <div class="client-card" data-status="${client.status}" data-gender="${client.gender}">
            <div class="client-header">
                <div class="client-avatar">
                    <img src="https://via.placeholder.com/60x60/${getAvatarColor(client.id)}/FFFFFF?text=${getInitials(client.name)}" alt="${client.name}">
                </div>
                <div class="client-info">
                    <h3>${client.name}</h3>
                    <p>${client.email}</p>
                    <span class="client-status ${client.status}">${client.status === 'ativo' ? 'Ativo' : 'Inativo'}</span>
                </div>
            </div>
            
            <div class="client-details">
                <div class="detail-item">
                    <i class="fas fa-birthday-cake"></i>
                    <span>${client.age} anos</span>
                </div>
                <div class="detail-item">
                    <i class="fas fa-${client.gender === 'feminino' ? 'venus' : 'mars'}"></i>
                    <span>${client.gender === 'feminino' ? 'Feminino' : 'Masculino'}</span>
                </div>
                <div class="detail-item">
                    <i class="fas fa-shopping-bag"></i>
                    <span>${client.purchaseCount} compras</span>
                </div>
                <div class="detail-item">
                    <i class="fas fa-dollar-sign"></i>
                    <span>R$ ${client.totalPurchases.toFixed(2).replace('.', ',')}</span>
                </div>
            </div>
            
            <div class="client-last-purchase">
                <h4>Última Compra</h4>
                <p>${client.lastPurchase}</p>
                <small>${client.lastPurchaseDate}</small>
            </div>
            
            <div class="client-actions">
                <button class="btn-view" onclick="viewClient(${client.id})">
                    <i class="fas fa-eye"></i>
                    Ver Detalhes
                </button>
                <button class="btn-edit" onclick="editClient(${client.id})">
                    <i class="fas fa-edit"></i>
                    Editar
                </button>
            </div>
        </div>
    `).join('');
}

// Renderizar visualização em tabela
function renderTableView() {
    const tbody = document.querySelector('.clients-table tbody');
    if (!tbody) return;

    tbody.innerHTML = filteredClients.map(client => `
        <tr>
            <td>
                <div class="table-client">
                    <img src="https://via.placeholder.com/40x40/${getAvatarColor(client.id)}/FFFFFF?text=${getInitials(client.name)}" alt="${client.name}">
                    <div>
                        <strong>${client.name}</strong>
                        <small>${client.age} anos, ${client.gender === 'feminino' ? 'Feminino' : 'Masculino'}</small>
                    </div>
                </div>
            </td>
            <td>${client.email}</td>
            <td>${client.phone}</td>
            <td>${client.cpf}</td>
            <td>${client.addresses} endereço${client.addresses > 1 ? 's' : ''}</td>
            <td>${client.cards} cartão${client.cards > 1 ? 'es' : ''}</td>
            <td>R$ ${client.totalPurchases.toFixed(2).replace('.', ',')}</td>
            <td><span class="status-badge ${client.status}">${client.status === 'ativo' ? 'Ativo' : 'Inativo'}</span></td>
            <td>
                <div class="table-actions">
                    <button class="btn-icon" onclick="viewClient(${client.id})" title="Ver Detalhes">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn-icon" onclick="editClient(${client.id})" title="Editar">
                        <i class="fas fa-edit"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

// Atualizar estatísticas
function updateStats() {
    const totalClients = clientsData.length;
    const activeClients = clientsData.filter(c => c.status === 'ativo').length;
    const totalSales = clientsData.reduce((sum, c) => sum + c.totalPurchases, 0);
    const avgSatisfaction = 4.8; // Valor fixo para demonstração

    // Atualizar elementos na página
    const statCards = document.querySelectorAll('.stat-card');
    if (statCards.length >= 4) {
        statCards[0].querySelector('h3').textContent = totalClients.toLocaleString();
        statCards[1].querySelector('h3').textContent = activeClients.toLocaleString();
        statCards[2].querySelector('h3').textContent = `R$ ${totalSales.toLocaleString('pt-BR', { minimumFractionDigits: 0 })}`;
        statCards[3].querySelector('h3').textContent = avgSatisfaction.toFixed(1);
    }
}

// Funções auxiliares
function getAvatarColor(id) {
    const colors = ['E74C3C', '3498DB', '95A5A6', '27AE60', 'F39C12', '9B59B6'];
    return colors[id % colors.length];
}

function getInitials(name) {
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
}

// Ações dos clientes
function viewClient(id) {
    // Redirecionar para página de detalhes
    window.location.href = `pages/client-details.html?id=${id}`;
}

function editClient(id) {
    // Redirecionar para página de edição
    window.location.href = `pages/client-form.html?id=${id}`;
}

function openClientModal() {
    // Redirecionar para página de novo cliente
    window.location.href = 'pages/client-form.html';
}

// Funções de notificação
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    document.body.appendChild(notification);

    // Auto-remover após 5 segundos
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Função para confirmar ações
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// Exportar funções para uso global
window.viewClient = viewClient;
window.editClient = editClient;
window.openClientModal = openClientModal;
window.showNotification = showNotification;
window.confirmAction = confirmAction;

